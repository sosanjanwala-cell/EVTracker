"""Video -> exit velocity, built for tee work with a camera that doesn't move.

1. Find the ball sitting on the tee (your tap on the preview, or YOLO on the first frame).
2. Measure its width in pixels. A baseball is about 2.9 in across, so that sets the scale
   right where the ball flies.
3. Watch the tee spot until it changes. That's contact.
4. Follow the moving ball for the next few frames and fit its speed and angle.
"""
import cv2
import numpy as np

from tracker import fit_velocity, launch_angle_deg, speed_mph

BALL_CLASS = 32          # COCO "sports ball"
MAX_EV_MPH = 135         # fastest ball we'll believe; limits how far it can move per frame
TRACK_FRAMES = 20        # frames after contact to look at
FIT_POINTS = 8           # ball positions used for the speed fit


def _gray(frame):
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def _measure_ball(gray, cx, cy, search_r):
    """Find the ball near (cx, cy) and measure its width. Tries smaller areas if it merges with other stuff."""
    h, w = gray.shape
    for r in (search_r, search_r / 2, search_r / 4):
        x0, y0 = max(0, int(cx - r)), max(0, int(cy - r))
        x1, y1 = min(w, int(cx + r)), min(h, int(cy + r))
        roi = cv2.GaussianBlur(gray[y0:y1, x0:x1], (5, 5), 0)
        if roi.size < 100:
            continue
        _, th = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        px = int(np.clip(cx - x0, 0, roi.shape[1] - 1))
        py = int(np.clip(cy - y0, 0, roi.shape[0] - 1))
        brighter = th[py, px] > 0
        if not brighter:  # ball darker than its background (e.g. bright sky): flip
            th = 255 - th
        n, labels, stats, cents = cv2.connectedComponentsWithStats(th)
        if n < 2:
            continue
        lbl = labels[py, px]
        if lbl == 0:  # tap landed just off the ball: take the nearest blob
            lbl = 1 + int(np.argmin([np.hypot(*(cents[i] - (px, py))) for i in range(1, n)]))
        bx, by, bw, bh, _ = stats[lbl]
        # Width is used for scale because the tee sits below the ball and can't widen it.
        if bw < 5 or bw > 1.6 * r or not 0.6 <= bw / max(bh, 1) <= 1.7:
            continue
        comp = labels == lbl
        ball_val, bg_val = float(roi[comp].mean()), float(roi[~comp].mean())
        raw = gray[y0:y1, x0:x1].astype(np.float32)
        width = _subpixel_width(raw, comp, bx, bw, int(cents[lbl][1]), brighter) or float(bw)
        return {
            "cx": x0 + float(cents[lbl][0]), "cy": y0 + float(cents[lbl][1]),
            "d": width, "box": (x0 + int(bx), y0 + int(by), int(bw), int(bh)),
            "brighter": bool(brighter), "thr": (ball_val + bg_val) / 2,
            "contrast": abs(ball_val - bg_val),
        }
    return None


def _subpixel_width(raw, comp, bx, bw, cy, brighter):
    """Ball width to a fraction of a pixel: across the rows near the ball's middle, add up how
    'ball-like' each pixel is (0 = background, 1 = ball). Blurry edge pixels count partially."""
    widths = []
    for r in range(max(cy - 2, 0), min(cy + 3, raw.shape[0])):
        a, b = max(bx - 4, 0), min(bx + bw + 4, raw.shape[1])
        row = raw[r, a:b]
        outside = np.concatenate([raw[r, max(a - 6, 0):a], raw[r, b:b + 6]])
        inside = raw[r][comp[r]]
        if len(outside) < 3 or len(inside) < 3:
            continue
        bg, ball = float(np.median(outside)), float(np.median(inside))
        if abs(ball - bg) < 10:
            continue
        frac = (row - bg) / (ball - bg)
        widths.append(float(np.clip(frac, 0, 1).sum()))
    return max(widths) if widths else None


def _yolo_find(frames, model):
    best = None
    for f in frames:
        r = model.predict(f, imgsz=1280, conf=0.1, classes=[BALL_CLASS], verbose=False)[0]
        for b in r.boxes:
            p = float(b.conf[0])
            x1, y1, x2, y2 = b.xyxy[0].tolist()
            if best is None or p > best[0]:
                best = (p, (x1 + x2) / 2, (y1 + y2) / 2, x2 - x1)
    return best


def analyze_video(path, *, hint=None, ball_diameter_in=2.9, fps_override=0, max_frames=1200,
                  get_model=None, out_image=None):
    """hint: (x, y) as fractions of the frame (0-1) where the user tapped the ball, or None.
    get_model: function returning a YOLO model, only called if there's no hint.
    Raises ValueError with a readable message when it can't get a result.
    """
    warnings = []
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise ValueError("Couldn't open that video file.")
    file_fps = cap.get(cv2.CAP_PROP_FPS) or 0
    fps = fps_override or file_fps or 240.0
    if not fps_override and file_fps < 100:
        warnings.append(f"The file says {file_fps:.0f} fps. Slo-mo should be 120 or 240. "
                        "If you filmed in slo-mo, set Real FPS in settings or the number will be way off.")

    head = []
    for _ in range(5):
        ok, f = cap.read()
        if not ok:
            break
        head.append(f)
    if not head:
        raise ValueError("That video has no readable frames.")
    H, W = head[0].shape[:2]
    ref = np.median(np.stack([_gray(f) for f in head]), axis=0).astype(np.uint8)
    ref_mean = float(ref.mean())

    # ---- 1-2. Find and measure the ball on the tee ----
    if hint:
        ball = _measure_ball(ref, hint[0] * W, hint[1] * H, 0.08 * max(W, H))
    else:
        if get_model is None:
            raise ValueError("Tap the ball in the preview so the app knows where it is.")
        found = _yolo_find(head[:3], get_model())
        ball = _measure_ball(ref, found[1], found[2], 1.5 * max(found[3], 10)) if found else None
    if ball is None:
        raise ValueError("Couldn't find the ball on the tee. Tap right on the ball in the preview and try again.")
    d = ball["d"]
    ppi = d / ball_diameter_in
    if d < 15:
        warnings.append(f"The ball is only {d:.0f} px wide. Film closer (aim for 30+ px) for accurate numbers.")

    # ---- 3. Watch the tee spot for contact ----
    bx, by, bw, bh = ball["box"]
    rx0, ry0, rx1, ry1 = bx, by, bx + bw, by + bh  # the ball's own spot
    ref_roi = ref[ry0:ry1, rx0:rx1].astype(np.float32)
    dthr = max(20.0, 0.5 * ball["contrast"])

    def frames():
        for f in head[1:]:
            yield f
        while True:
            ok, f = cap.read()
            if not ok:
                return
            yield f

    contact, post = None, []
    for i, f in enumerate(frames(), start=1):
        if i >= max_frames:
            break
        if contact is None:
            g = _gray(f)
            roi = g[ry0:ry1, rx0:rx1].astype(np.float32)
            roi -= float(g[::4, ::4].mean()) - ref_mean  # ignores light flicker
            if (np.abs(roi - ref_roi) > dthr).mean() > 0.35:
                contact = i
                post.append((i, f))
        else:
            post.append((i, f))
            if len(post) > TRACK_FRAMES:
                break
    cap.release()
    if contact is None:
        raise ValueError("Never saw the ball get hit. Make sure the swing is in the clip, the camera "
                         "doesn't move, or raise Max frames for longer clips.")

    # ---- 4. Follow the ball after contact ----
    tee = np.array([ball["cx"], ball["cy"]])
    area = np.pi * (d / 2) ** 2
    max_step = MAX_EV_MPH * 5280 * 12 / 3600 * ppi / fps  # px per frame at max EV
    kernel = np.ones((3, 3), np.uint8)
    track, track_frames, misses, g_prev = [], [], 0, None

    for fi, f in post:
        g = _gray(f).astype(np.float32)
        g -= g.mean() - ref_mean  # ignores light flicker
        changed = np.abs(g - g_prev) > dthr if g_prev is not None else np.ones_like(g, bool)
        g_prev = g
        moved = np.abs(g - ref) > dthr
        colored = g > ball["thr"] if ball["brighter"] else g < ball["thr"]
        mask = cv2.morphologyEx((moved & colored).astype(np.uint8) * 255, cv2.MORPH_OPEN, kernel)
        n, labels, stats, cents = cv2.connectedComponentsWithStats(mask)
        # A flying ball is a ball-sized blob that is also changing from the previous frame
        cands = [(cents[k], stats[k, 4]) for k in range(1, n)
                 if 0.15 * area <= stats[k, 4] <= 8 * area and changed[labels == k].mean() > 0.15]

        pick = None
        if not track:
            reach = max_step * max(fi - contact, 1) + d
            ok = [(c, a) for c, a in cands if 0.6 * d <= np.linalg.norm(c - tee) <= reach]
            if ok:  # closest in size to the ball, and not too far
                pick = min(ok, key=lambda ca: abs(np.log(ca[1] / area)) + np.linalg.norm(ca[0] - tee) / reach)[0]
        else:
            last, gap = np.array(track[-1][1:]), fi - track[-1][0]
            if len(track) >= 2:
                prev = np.array(track[-2][1:])
                v = (last - prev) / (track[-1][0] - track[-2][0])
                pred, gate = last + v * gap, 0.6 * np.linalg.norm(v) * gap + d
            else:
                pred, gate = last, max_step * gap + d
            ok = [c for c, _ in cands if np.linalg.norm(c - pred) <= gate
                  and np.linalg.norm(c - tee) > np.linalg.norm(last - tee)]
            if ok:
                pick = min(ok, key=lambda c: np.linalg.norm(c - pred))

        if pick is not None:
            track.append((fi, float(pick[0]), float(pick[1])))
            track_frames.append(f)
            misses = 0
            if len(track) >= FIT_POINTS:
                break
        elif track:
            misses += 1
            if misses >= 4:
                break

    if len(track) < 3:
        raise ValueError(f"Saw contact but could only follow the ball for {len(track)} frame(s). Try brighter "
                         "light, a plainer background behind the ball's path, or a white ball.")

    v, rms = fit_velocity(track)
    raw_mph = speed_mph(v, fps, ppi)
    if not 10 <= raw_mph <= MAX_EV_MPH:
        warnings.append(f"{raw_mph:.0f} mph looks off. Check Real FPS and the track image.")

    if out_image:
        img = track_frames[-1].copy()
        cv2.circle(img, (int(tee[0]), int(tee[1])), int(d / 2), (255, 128, 0), 2)  # measured ball (blue)
        prev = None
        for _, x, y in track:
            p = (int(x), int(y))
            cv2.circle(img, p, max(int(d / 2), 4), (0, 255, 0), 2)
            if prev:
                cv2.line(img, prev, p, (0, 255, 255), 2)
            prev = p
        if W > 1280:
            img = cv2.resize(img, (1280, int(H * 1280 / W)))
        cv2.imwrite(out_image, img)

    return {
        "raw_mph": float(raw_mph),
        "launch_angle": launch_angle_deg(v),
        "fps": float(fps),
        "ball_px": d,
        "track_points": len(track),
        "rms_px": float(rms),
        "contact_frame": contact,
        "warnings": warnings,
    }
