"""EV Tracker web server.

Run:  uvicorn server:app --reload     then open http://localhost:8000
"""
import shutil
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from detection import analyze_video

BASE = Path(__file__).parent
DATA = BASE / "data"
VIDEOS, TRACKS = DATA / "videos", DATA / "tracks"
for d in (VIDEOS, TRACKS):
    d.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / "trials.db"
ALLOWED_EXT = {".mp4", ".mov", ".m4v", ".avi"}
_model = None


def get_model():
    """YOLO is only used to find the ball on the tee when you don't tap it."""
    global _model
    if _model is None:
        from ultralytics import YOLO
        _model = YOLO("yolo11s.pt")  # downloads on first use
    return _model


@contextmanager
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


with db() as con:
    con.execute("""CREATE TABLE IF NOT EXISTS trials(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, notes TEXT, video TEXT,
        track_image TEXT, fps REAL, raw_mph REAL, launch_angle REAL, sensor_mph REAL,
        ball_px REAL, track_points INTEGER, rms_px REAL)""")
    have = {r[1] for r in con.execute("PRAGMA table_info(trials)")}
    for col, typ in (("ball_px", "REAL"), ("track_points", "INTEGER")):  # upgrade older databases
        if col not in have:
            con.execute(f"ALTER TABLE trials ADD COLUMN {col} {typ}")
    con.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)")


def get_factor(con):
    row = con.execute("SELECT value FROM settings WHERE key='calibration_factor'").fetchone()
    return float(row["value"]) if row else 1.0


def serialize(row, factor):
    d = dict(row)
    d["calibrated_mph"] = round(d["raw_mph"] * factor, 1)
    d["raw_mph"] = round(d["raw_mph"], 1)
    d["launch_angle"] = round(d["launch_angle"], 1)
    d["error_mph"] = (round(d["calibrated_mph"] - d["sensor_mph"], 1)
                      if d["sensor_mph"] is not None else None)
    d["track_url"] = f"/tracks/{d['track_image']}"
    return d


app = FastAPI(title="EV Tracker")


@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")


@app.post("/api/trials")
def create_trial(
    video: UploadFile = File(...),
    notes: str = Form(""),
    sensor_mph: float | None = Form(None),
    hint_x: float | None = Form(None),
    hint_y: float | None = Form(None),
    ball_diameter_in: float = Form(2.9),
    fps: float = Form(0),
    max_frames: int = Form(1200),
):
    ext = Path(video.filename or "").suffix.lower() or ".mp4"
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, "Upload an .mp4, .mov, .m4v, or .avi file.")
    hint = (hint_x, hint_y) if hint_x is not None and hint_y is not None else None

    uid = uuid.uuid4().hex
    vpath, track_name = VIDEOS / f"{uid}{ext}", f"{uid}.jpg"
    with open(vpath, "wb") as f:
        shutil.copyfileobj(video.file, f)

    try:
        res = analyze_video(str(vpath), hint=hint, ball_diameter_in=ball_diameter_in,
                            fps_override=fps, max_frames=max_frames, get_model=get_model,
                            out_image=str(TRACKS / track_name))
    except ValueError as e:
        vpath.unlink(missing_ok=True)
        raise HTTPException(422, str(e))

    with db() as con:
        cur = con.execute(
            """INSERT INTO trials(created_at, notes, video, track_image, fps, raw_mph, launch_angle,
               sensor_mph, ball_px, track_points, rms_px) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (datetime.now(timezone.utc).isoformat(), notes, vpath.name, track_name, res["fps"],
             res["raw_mph"], res["launch_angle"], sensor_mph, res["ball_px"],
             res["track_points"], res["rms_px"]))
        row = con.execute("SELECT * FROM trials WHERE id=?", (cur.lastrowid,)).fetchone()
        out = serialize(row, get_factor(con))
    out["warnings"] = res["warnings"]
    return out


@app.get("/api/trials")
def list_trials():
    with db() as con:
        factor = get_factor(con)
        return [serialize(r, factor) for r in con.execute("SELECT * FROM trials ORDER BY id DESC")]


class TrialUpdate(BaseModel):
    sensor_mph: float | None = None
    notes: str | None = None


@app.patch("/api/trials/{trial_id}")
def update_trial(trial_id: int, body: TrialUpdate):
    with db() as con:
        if not con.execute("SELECT 1 FROM trials WHERE id=?", (trial_id,)).fetchone():
            raise HTTPException(404, "Trial not found.")
        if "sensor_mph" in body.model_fields_set:  # null clears it
            con.execute("UPDATE trials SET sensor_mph=? WHERE id=?", (body.sensor_mph, trial_id))
        if body.notes is not None:
            con.execute("UPDATE trials SET notes=? WHERE id=?", (body.notes, trial_id))
        row = con.execute("SELECT * FROM trials WHERE id=?", (trial_id,)).fetchone()
        return serialize(row, get_factor(con))


@app.delete("/api/trials/{trial_id}")
def delete_trial(trial_id: int):
    with db() as con:
        row = con.execute("SELECT * FROM trials WHERE id=?", (trial_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Trial not found.")
        (VIDEOS / row["video"]).unlink(missing_ok=True)
        (TRACKS / row["track_image"]).unlink(missing_ok=True)
        con.execute("DELETE FROM trials WHERE id=?", (trial_id,))
    return {"ok": True}


@app.get("/api/stats")
def stats():
    with db() as con:
        factor = get_factor(con)
        rows = con.execute("SELECT raw_mph, sensor_mph FROM trials WHERE sensor_mph IS NOT NULL").fetchall()
    if not rows:
        return {"n": 0, "current_factor": factor}
    raw = np.array([r["raw_mph"] for r in rows])
    sensor = np.array([r["sensor_mph"] for r in rows])
    suggested = float((sensor * raw).sum() / (raw ** 2).sum())  # best single multiplier
    return {
        "n": len(rows),
        "current_factor": factor,
        "suggested_factor": round(suggested, 3),
        "mae_raw": round(float(np.abs(raw - sensor).mean()), 1),
        "mae_calibrated": round(float(np.abs(raw * factor - sensor).mean()), 1),
        "mae_if_suggested": round(float(np.abs(raw * suggested - sensor).mean()), 1),
    }


class FactorBody(BaseModel):
    calibration_factor: float


@app.put("/api/settings")
def set_factor(body: FactorBody):
    if not 0.5 <= body.calibration_factor <= 2.0:
        raise HTTPException(400, "Calibration factor must be between 0.5 and 2.0.")
    with db() as con:
        con.execute("INSERT INTO settings(key, value) VALUES('calibration_factor', ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(body.calibration_factor),))
    return {"calibration_factor": body.calibration_factor}


app.mount("/tracks", StaticFiles(directory=TRACKS), name="tracks")
