"""Pure math for the exit velocity tracker (no video or UI code)."""
import numpy as np

FTS_TO_MPH = 3600 / 5280  # feet/second -> miles/hour


def fit_velocity(pts):
    """Least-squares velocity of points [[frame, x, y], ...].

    Returns (np.array([vx, vy]) in px/frame, rms_residual_px).
    """
    pts = np.asarray(pts, float)
    if len(pts) < 2 or np.ptp(pts[:, 0]) == 0:
        return np.zeros(2), 0.0
    t = pts[:, 0]
    px = np.polyfit(t, pts[:, 1], 1)
    py = np.polyfit(t, pts[:, 2], 1)
    rx = pts[:, 1] - np.polyval(px, t)
    ry = pts[:, 2] - np.polyval(py, t)
    return np.array([px[0], py[0]]), float(np.sqrt(np.mean(rx**2 + ry**2)))


def speed_mph(v_px_per_frame, fps, px_per_in):
    """Pixel velocity vector -> mph."""
    ft_per_s = float(np.linalg.norm(v_px_per_frame)) * fps / (px_per_in * 12.0)
    return ft_per_s * FTS_TO_MPH


def launch_angle_deg(v_px_per_frame):
    """Angle above horizontal. Image y points down, so flip it."""
    vx, vy = v_px_per_frame
    return float(np.degrees(np.arctan2(-vy, abs(vx))))
